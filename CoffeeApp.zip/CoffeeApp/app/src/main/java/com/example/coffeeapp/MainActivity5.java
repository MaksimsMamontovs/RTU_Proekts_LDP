package com.example.coffeeapp;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import android.widget.Button;

import com.google.android.material.textfield.TextInputLayout;

import java.util.Random;

public class MainActivity5 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main5);
        configureNextButton3();
    }



    private void configureNextButton3(){
        Button nextBut= (Button) findViewById(R.id.Button_back3);
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity5.this);
        TextInputLayout textInputLayout = findViewById(R.id.text5);
        Random rand = new Random();
        nextBut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                builder.setMessage("Are you sure you want to order?")
                        .setPositiveButton("Ok", new DialogInterface.OnClickListener() {

                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                finish();
                                Editable text = textInputLayout.getEditText().getText();
                                System.out.println(" ");
                                System.out.println("New order for KAPUCHINO ");
                                System.out.println("Order Number:"+9584 + rand.nextInt(1000));
                                System.out.println("Users orders comments: "+text);
                            }
                        })
                        .setNegativeButton("Cancel",null);
                AlertDialog alert = builder.create();
                alert.show();
            }
        });
    }
}