package com.example.coffeeapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);



    configureNextButton();
    configureNextButtonOrder1();
    configureNextButtonOrder2();
    configureNextButtonOrder3();
    configureNextButtonOrder4();
}


    private void configureNextButton(){
        Button nextBut= (Button) findViewById(R.id.Button_back);
        nextBut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    private void configureNextButtonOrder1(){
        Button nextBut= (Button) findViewById(R.id.button_Offer1);
        nextBut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity2.this,MainActivity3.class));
            }
        });


    }
    private void configureNextButtonOrder2(){
        Button nextBut= (Button) findViewById(R.id.button_Offer2);
        nextBut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity2.this,MainActivity4.class));
            }
        });


    }private void configureNextButtonOrder3(){
        Button nextBut= (Button) findViewById(R.id.button_Offer3);
        nextBut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity2.this,MainActivity5.class));
            }
        });


    }private void configureNextButtonOrder4(){
        Button nextBut= (Button) findViewById(R.id.button_Offer4);
        nextBut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity2.this,MainActivity6.class));
            }
        });


    }



}