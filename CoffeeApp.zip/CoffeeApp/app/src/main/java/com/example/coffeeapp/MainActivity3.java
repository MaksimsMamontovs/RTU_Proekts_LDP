package com.example.coffeeapp;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import android.widget.Button;

import com.google.android.material.textfield.TextInputLayout;

import java.util.Random;

public class MainActivity3 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        configureNextButton1();
    }

    private void configureNextButton1(){
        Button nextBut= (Button) findViewById(R.id.Button_back1);
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity3.this);
        TextInputLayout textInputLayout = findViewById(R.id.text3);
        Random rand = new Random();
        nextBut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                builder.setMessage("Are you sure you want to order?")
                        .setPositiveButton("Ok", new DialogInterface.OnClickListener() {

                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                finish();
                                Editable text = textInputLayout.getEditText().getText();
                                System.out.println(" ");
                                System.out.println("New order for MELNO KAFIJU ");
                                System.out.println("Order Number:"+9584 + rand.nextInt(1000));
                                System.out.println("Users orders comments: "+text);
                            }
                        })
                        .setNegativeButton("Cancel",null);
                AlertDialog alert = builder.create();
                alert.show();
            }
        });
    }
}



