package com.example.coffeeapp;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import android.widget.Button;
import java.util.Random;
import com.google.android.material.textfield.TextInputLayout;

public class MainActivity6 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main6);
        configureNextButton4();
    }

    private void configureNextButton4(){
        Button nextBut= (Button) findViewById(R.id.Button_back4);
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity6.this);
        TextInputLayout textInputLayout = findViewById(R.id.text6);
        Random rand = new Random();
        nextBut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                builder.setMessage("Are you sure you want to order?")
                        .setPositiveButton("Ok", new DialogInterface.OnClickListener() {

                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                finish();
                                Editable text = textInputLayout.getEditText().getText();
                                System.out.println(" ");
                                System.out.println("New order for ESPRESSO ");
                                System.out.println("Order Number:"+9584 + rand.nextInt(1000));
                                System.out.println("Users orders comments: "+text);
                            }
                        })
                        .setNegativeButton("Cancel",null);
                AlertDialog alert = builder.create();
                alert.show();
            }
        });
    }
}